# Searching for the Essentials

Mapping Project. 

__Vivien, Nele, & Esmé__ 

## Quick Start Installation & Usage
1. Clone this repository,
2. Create and activate a virtual Environment, `pip install virtualenv`, `virtualenv venv`, `venv\Scripts\activate` (Windows) or `source venv/bin/activate` (Mac)
3. Run `pip install -r requirements.txt`
4. Run `python index.py` to view your Dashboard.

### Attribution
[Plotly's Dash](https://github.com/plotly/dash)
